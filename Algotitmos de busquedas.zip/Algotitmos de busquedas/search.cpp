#include  <iostream> 
#include  <vector> 
#include  <random> 
#include  <chrono> 
#include  <algorithm> 


using namespace std;
using namespace std::chrono;
int busquedaSecuencial(vector  <  int >  a, int search)
{
	for(int i = 0; i  <   a.size(); i++)
	{
		if(a[i]  ==  search)
		{
			return i;
		}
	}
	return -1;
}

int busquedaOrden1(vector  <  int >  a, int search)
{
	for(int i = 0; i  <   a.size(); i++)
	{
		if(a[i] > search)
		{
			return -1;
		}
		if(a[i] == search)
		{
			return i;
		}
	}
	return -1;
}

int busquedaOrden2(vector  <  int >  a, int search)
{
	int paso=2;
	int start=0;
	int final;
	while(start  <   a.size())
	{
		final=start+paso;
		if(final  >  a.size())
		{
			final = a.size();
		}
		if(a[final-1] >=search)
		{
			for(int i = start; i <  final; i++)
			{
				if(a[i] == search)
				{
					return i;
				}
			}
			return -1;
		}
		start=final;
	}
	return -1;
}

int binarySearch(vector <  int > a, int search)
{
	int start = 0;
	int final = a.size()-1;
	if(search > a[final] || search <  a[start])
	{
		return -1;
	}
	while(final >= start)
	{
		int mid = (start+final)/2;
		if(a[mid] == search)
		{
			return mid;
		}else if(search > a[mid])
		{
			start = mid+1;
		}else
		{
			final = mid-1;
		}
	}
	return -1;
}

int main()
{
	vector <  int >  a;
	std::default_random_engine generator;
	std::uniform_int_distribution <  int >  distribution(1,10000000);
	for(int i=0; i <  1000000; i++)
	{
		a.push_back(distribution(generator));

	}
	
	sort(a.begin(), a.end());

	int search = a[27]; //busqueda

	int x; // de secuencias
	cout <<  "Secuencial ";

	auto start=high_resolution_clock::now();
	x=busquedaSecuencial(a,search);

	auto final=high_resolution_clock::now();
	auto tiempo=duration_cast <  microseconds > (final - start).count();

	cout <<  "posicion: " <<  x <<  ", tiempo: " <<  tiempo <<  endl;

	// ordenada1
	cout <<  "Ordenada 1 ";
	start=high_resolution_clock::now();
	x=busquedaOrden1(a,search);
	final=high_resolution_clock::now();
	tiempo=duration_cast <  microseconds > (final - start).count();

	cout <<  "posicion: " <<  x <<  ", tiempo: " <<  tiempo <<  endl;

	// ordenada2
	cout <<  "Ordenada 2 ";
	start=high_resolution_clock::now();
	x=busquedaOrden2(a,search);
	final=high_resolution_clock::now();
	tiempo=duration_cast <  microseconds > (final - start).count();

	cout <<  "posicion: " <<  x <<  ", tiempo: " <<  tiempo <<  endl;

	// busq. binaria
	cout <<  "Binaria ";
	start=high_resolution_clock::now();
	x=binarySearch(a,search);

	final=high_resolution_clock::now();
	tiempo=duration_cast <  microseconds > (final - start).count();

	cout <<  "posicion: " <<  x <<  ", tiempo: " <<  tiempo <<  endl;

	return 0;
}